---
id: task-58
type: task
title: followup agent prompt snippet and example pack shapes
status: done
priority: 1
epic: epic-6
tags: [v0_4x, docs, llm, examples]
owners: []
links: []
artifacts: []
relates: [prd-2, dec-11, edd-9, task-45, task-64, test-27, epic-6]
blocked_by: []
blocks: [test-27]
refs: []
aliases: []
created: 2026-03-05
updated: 2026-03-05
---

# Overview

Add prompt snippet and representative task/edd/skills pack examples for docs consumption.

# Acceptance Criteria

- Prompt snippet is deterministic and pack-first.
- Prompt snippet assumes a generic mdkg OSS repo first, not an Omni-specific environment.
- Example pack docs stay synchronized with current pack output contracts.

# Files Affected

- README.md
- docs placeholder path (tbd)

# Implementation Notes

- Non-blocking follow-up for post-0.0.4 cut.

# Test Plan

- Validate via `test-27` artifact checks.

# Links / Artifacts

- prd-2
- dec-11
- epic-6
