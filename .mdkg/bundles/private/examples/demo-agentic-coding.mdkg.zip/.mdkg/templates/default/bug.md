---
id: {{id}}
type: bug
title: {{title}}
status: {{status}}
priority: {{priority}}
epic: {{epic}}
parent: {{parent}}
prev: {{prev}}
next: {{next}}
tags: []
owners: []
links: []
artifacts: []
relates: []
blocked_by: []
blocks: []
refs: []
context_refs: []
evidence_refs: []
aliases: []
skills: []
created: {{created}}
updated: {{updated}}
---

# Overview

What is broken? What’s the impact?

# Reproduction Steps

1. step 1
2. step 2

# Expected vs Actual

- expected:
- actual:

# Suspected Cause

Hypotheses or known causes.

# Fix Plan

What needs to change?

# Test Plan

How will we verify the fix?

# Links / Artifacts

- logs
- screenshots
- related tasks
